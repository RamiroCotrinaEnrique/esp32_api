# ESP32-fritzing-module
The Espressif ESP32 module for use with Fritzing PCB prototyping software. Formfactor fits both ESP-WROOM-32 and ESP-32S.
